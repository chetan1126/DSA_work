#include <stdio.h>
#include <stdlib.h>

#define MAX 5
int queue[MAX], front = -1, rear = -1;

void isQueueFull() {
    if (rear == MAX - 1) printf("Queue Full\n");
    else printf("Queue Not Full\n");
}

void isQueueEmpty() {
    if (front == -1 || front > rear) printf("Queue Empty\n");
    else printf("Queue Not Empty\n");
}

void add(int val) {
    if (rear == MAX - 1) printf("Overflow\n");
    else {
        if (front == -1) front = 0;
        queue[++rear] = val;
    }
}

void delete() {
    if (front == -1 || front > rear) printf("Underflow\n");
    else printf("Deleted: %d\n", queue[front++]);
}

void peep() {
    if (front == -1 || front > rear) printf("Empty\n");
    else printf("Front: %d\n", queue[front]);
}

void displayQueue() {
    if (front == -1 || front > rear) printf("Empty\n");
    else {
        for (int i = front; i <= rear; i++) printf("%d ", queue[i]);
        printf("\n");
    }
}

int main() {
    int choice, val;
    while(1) {
        printf("\n1.Add 2.Delete 3.Peep 4.Display 5.Full? 6.Empty? 7.Exit: ");
        scanf("%d", &choice);
        switch(choice) {
            case 1: printf("Val: "); scanf("%d", &val); add(val); break;
            case 2: delete(); break;
            case 3: peep(); break;
            case 4: displayQueue(); break;
            case 5: isQueueFull(); break;
            case 6: isQueueEmpty(); break;
            case 7: exit(0);
        }
    }
}