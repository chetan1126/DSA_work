#include <stdio.h>
#include <stdlib.h>

#define MAX 5
int cqueue[MAX], f = -1, r = -1;

void isQueueFull() {
    if ((r + 1) % MAX == f) printf("Queue Full\n");
    else printf("Not Full\n");
}

void isQueueEmpty() {
    if (f == -1) printf("Queue Empty\n");
    else printf("Not Empty\n");
}

void add(int val) {
    if ((r + 1) % MAX == f) printf("Overflow\n");
    else {
        if (f == -1) f = 0;
        r = (r + 1) % MAX;
        cqueue[r] = val;
    }
}

void delete() {
    if (f == -1) printf("Underflow\n");
    else {
        printf("Deleted: %d\n", cqueue[f]);
        if (f == r) f = r = -1;
        else f = (f + 1) % MAX;
    }
}

void peep() {
    if (f == -1) printf("Empty\n");
    else printf("Front: %d\n", cqueue[f]);
}

void displayQueue() {
    if (f == -1) printf("Empty\n");
    else {
        int i = f;
        while (1) {
            printf("%d ", cqueue[i]);
            if (i == r) break;
            i = (i + 1) % MAX;
        }
        printf("\n");
    }
}

int main() {
    int choice, val;
    while(1) {
        printf("\n1.Add 2.Delete 3.Peep 4.Display 5.Full? 6.Empty? 7.Exit: ");
        scanf("%d", &choice);
        switch(choice) {
            case 1: printf("Val: "); scanf("%d", &val); add(val); break;
            case 2: delete(); break;
            case 3: peep(); break;
            case 4: displayQueue(); break;
            case 5: isQueueFull(); break;
            case 6: isQueueEmpty(); break;
            case 7: exit(0);
        }
    }
}