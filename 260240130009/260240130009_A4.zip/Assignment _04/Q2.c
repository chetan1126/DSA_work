#include <stdio.h>
#include <stdlib.h>

#define MAX 5
int stack[MAX], top = -1;

void isStackFull() {
    if (top == MAX - 1) printf("Stack is Full\n");
    else printf("Stack is not Full\n");
}

void isStackEmpty() {
    if (top == -1) printf("Stack is Empty\n");
    else printf("Stack is not Empty\n");
}

void push(int val) {
    if (top == MAX - 1) printf("Overflow\n");
    else stack[++top] = val;
}

void pop() {
    if (top == -1) printf("Underflow\n");
    else printf("Popped: %d\n", stack[top--]);
}

void peep() {
    if (top == -1) printf("Stack Empty\n");
    else printf("Top Element: %d\n", stack[top]);
}

void displayStack() {
    if (top == -1) printf("Empty\n");
    else {
        for (int i = top; i >= 0; i--) printf("%d ", stack[i]);
        printf("\n");
    }
}

int main() {
    int choice, val;
    while(1) {
        printf("\n1.Push 2.Pop 3.Peep 4.Display 5.Full? 6.Empty? 7.Exit: ");
        scanf("%d", &choice);
        switch(choice) {
            case 1: printf("Val: "); scanf("%d", &val); push(val); break;
            case 2: pop(); break;
            case 3: peep(); break;
            case 4: displayStack(); break;
            case 5: isStackFull(); break;
            case 6: isStackEmpty(); break;
            case 7: exit(0);
        }
    }
}