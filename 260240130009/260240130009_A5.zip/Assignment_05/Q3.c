#include <stdio.h>
#include <stdlib.h>

/*Global declarations*/

/*Global variable/Type declarations*/

struct node
{
    int data;
    struct node *next;
    struct node *prev;
};

/*Function declarations*/

void insertFromEnd(struct node **);
void insertFromBeg(struct node **);
void insertAtPos(struct node **, int);
void deleteFromEnd(struct node **);
void deleteFromBeg(struct node **);
void deleteAtPos(struct node **,int);
int listNodeCount(struct node *);
void display(struct node *);

int main()
{
    struct node *head;
    head = NULL;

    int choice = -1;

    int ele, count = 0;

    while (choice != 0)
    {
        printf("\n1.Insert from end"
               "\n2.Insert from begining"
               "\n3.Insert at position"
               "\n4.Delete from end"
               "\n5.Delete from begining"
               "\n6.Delete position"
	       "\n7.Node count"
               "\n8.Display List Of Nodes");

        printf("\nPlease enter your choice : ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            insertFromEnd(&head);
            break;

        case 2:
            insertFromBeg(&head);
            break;

        case 3:
            count = listNodeCount(head);
            insertAtPos(&head, count);
	    break;

        case 4:
            deleteFromEnd(&head);
            break;

        case 5:
            deleteFromBeg(&head);
            break;

	case 6:
	    count = listNodeCount(head);
	    deleteAtPos(&head,count);
	    break;

        case 7:
            count = listNodeCount(head);
            if (count == 0)
                printf("List is empty\n");
	    else
		printf("%d",count);
	    break;

        case 8:
            display(head);
            break;
        }
    }

    printf("\nThanks Bye\n");
}

void display(struct node *pHead) 
{
    struct node *trav = pHead;
    if (pHead == NULL) 
    {
        printf("List is Empty\n");
    }

    do
    {
        printf("%d->", trav->data);
        trav = trav->next;
    } while (trav != pHead);
}

int listNodeCount(struct node *pHead)
{
    if (NULL == pHead)
    {
        printf("\n List is Empty");
        return 0;
    }

    struct node *trav = pHead;
    int count = 0;

    do
    {
        count++;
	trav = trav->next;
    } while (trav != pHead);

    return count;
}

void insertFromEnd(struct node **pHead)
{
    int ele;
    printf("Please enter data\n");
    scanf("%d", &ele);

    struct node *temp = (struct node *)malloc(sizeof(struct node));

    if (NULL == temp)
    {
        printf("malloc failed please try again...\n");
        return;
    }

    temp->data = ele;
    temp->next = NULL;
    temp->prev = NULL;

    if (NULL == *pHead)
    {
        *pHead = temp;
        temp->next = *pHead;
        temp->prev = *pHead;
        return;
    }

    struct node *trav = *pHead;
    struct node *tempHead = *pHead;

    while (trav->next != *pHead)
    {
        trav = trav->next;
    }

    temp->next = tempHead;
    temp->prev = trav;
    trav->next = temp;
    (*pHead)->prev = temp;

    return;
}

void insertFromBeg(struct node **pHead)
{
    int ele;
    printf("Please enter data\n");
    scanf("%d", &ele);

    struct node *temp = (struct node *)malloc(sizeof(struct node));

    if (NULL == temp)
    {
        printf("malloc failed please try again...\n");
        return;
    }

    temp->data = ele;
    temp->next = NULL;
    temp->prev = NULL;

    if (NULL == *pHead)
    {
        *pHead = temp;
        temp->next = *pHead;
        temp->prev = *pHead;

        return;
    }

    temp->next = *pHead;
    temp->prev = (*pHead)->prev;
    (*pHead)->prev->next = temp;
    (*pHead)->prev = temp;
    *pHead = temp;

    return;
}

void insertAtPos(struct node **pHead, int count)
{
    int pos, ele;
    printf("Please eneter the position of insertion\n");
    scanf("%d", &pos);

    if (pos < 1 || pos > count)
    {
        printf("Invalid position.....please try again with valid position\n");
        return;
    }

    if (pos == 1)
    {
        insertFromBeg(pHead);
        return;
    }

    if (pos == count)
    {
        insertFromEnd(pHead);
        return;
    }

    printf("\nPlease enter the value to be inserted\n");
    scanf("%d", &ele);

    struct node *temp = (struct node *)malloc(sizeof(struct node));

    if (NULL == temp)
    {
        printf("malloc failed please try again...\n");
        return;
    }

    temp->next = NULL;
    temp->prev = NULL;
    temp->data = ele;

    struct node *trav = *pHead;
    int i = 1;

    while (i < (pos - 1))
    {
        trav = trav->next;
    }

    temp->next = trav->next;
    trav->next->prev = temp;
    temp->prev = trav;
    trav->next = temp;

    return;
}

void deleteFromEnd(struct node **pHead)
{
    struct node *trav = *pHead;

    if (NULL == trav)
    {
        printf("Nothing to delete list is empty\n");
        return;
    }

    while (trav->next->next != *pHead)
    {
        trav = trav->next;
    }

    struct node *target = trav->next;

    if (target == *pHead)
    {
        free(target);
        *pHead = NULL;
        return;
    }

    trav->next = *pHead;
    (*pHead)->prev = trav;
    free(target);
    return;
}

void deleteFromBeg(struct node **pHead)
{
    struct node *target = *pHead;

    if (target->next == *pHead)
    {
        free(target);
        *pHead = NULL;
        return;
    }

    *pHead = target->next;
    (*pHead)->prev = target->prev;
    target->prev->next = *pHead;
    free(target);
    return;
}

void deleteAtPos(struct node **pHead, int count)
{
	int pos;
	int i =1;
	printf("Enter position to delete\n");
	scanf("%d", &pos);

	if(pos < 1 || pos > count)
	{
		printf("Invalid pos please try again...\n");
		return;
	}

	struct node *trav = *pHead;
	struct node *target;
	
	if(pos == 1)
	{
		deleteFromBeg(pHead);
		return;
	}

	if(pos == count)
	{
		deleteFromEnd(pHead);
		return;
	}

	while(i < (pos - 1))
	{
		trav = trav->next;
		i++;
	}
	
	target = trav->next;
	trav->next = target->next;
	target->next->prev = trav;
	free(target);

	return;
}
