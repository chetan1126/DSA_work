#include<stdio.h>
#include<stdlib.h>


struct node
{
	int data;
	int priority;
	struct node *next;
};


void insertSortedWay(struct node **);
void deleteFromQueue(struct node **);
void display(struct node *);


int main()
{
	struct node *head;
	head = NULL;

	int choice = -1;

	while(choice !=0)
	{

		printf("\n1.Insert in the queue"
			"\n2.Display queue"
			"\n3.Delete from queue"
			"\n0.exit");	
		printf("\nPlease enter your choice\n");
		scanf("%d",&choice);

		switch(choice)
		{
			case 1: insertSortedWay(&head);
				break;

			case 2: display(head);
				break;

			case 3: deleteFromQueue(&head);
				break; 

		}
	}

}

void display(struct node *pHead)
{
	struct node *trav = pHead;

	printf("\n");
	while(trav != NULL)
	{
		printf("| data->[%d] priority->[%d] |", trav->data,trav->priority);
		trav = trav->next;
	}
	printf("\n");
}

void insertSortedWay(struct node **pHead)
{
	int ele;
	int priority = 0;

	printf("Please enter value to enqueue\n");
	scanf("%d", &ele);
	
	printf("Please mention the priority of this insertion\n");
	scanf("%d",&priority);

	struct node *temp = (struct node*)malloc(sizeof(struct node));

	if(NULL == temp)
	{
		printf("\nmalloc failed please try again\n");
		return;
	}

	temp->data = ele;
	temp->priority = priority;
	temp->next = NULL;

	
	struct node *trav = *pHead;

	if(*pHead == NULL || (*pHead)->priority > priority)
	{
		temp->next = trav;
		*pHead = temp;
		return;
	}
	
	while(trav->next != NULL && trav->next->priority < priority)
	{
		trav = trav->next;
	}

	temp->next = trav->next;
	trav->next = temp;

	return;


}

void deleteFromQueue(struct node **pHead)
{
    struct node *trav = *pHead;

    if (NULL == trav || (*pHead)->next == NULL)
    {
	free(*pHead);
	*pHead = NULL;
        return;
    }

    while (trav->next->next != NULL)
    {
        trav = trav->next;
    }

    struct node *target = trav->next;


    trav->next = NULL;
    free(target);
    return;
}
