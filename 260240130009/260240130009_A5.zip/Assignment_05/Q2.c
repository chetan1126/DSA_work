#include <stdio.h>
#include <stdlib.h>

// Singly Circular Linked List //

struct node
{
	int data;
	struct node *next;
	struct node *prev;
};

struct node *head = NULL;

void insertAtEnd(int);
void insertAtBeg(int);
void insertAtPos(int, int,int);
int listNodeCount();
void deleteFromEnd();
void deleteFromBeg();
void deleteFromPos(int, int);
void display();

int main()
{
	int choice = -1;
	int ele, pos = 0;
	int count = 0;
	while (choice != 0)
	{
		printf("\n1.insert at end"
			"\n2.insert begining"
			"\n3.insert at position"
			"\n4.display"
			"\n5.node count"
			"\n6.delete from end"
			"\n7.delete from begining"
			"\n8.delete from pos"
			"\n0.to exit");
		scanf("%d", &choice);

		switch (choice)
		{
		case 1:
			printf("Enter element to insert\n");
			scanf("%d", &ele);
			insertAtEnd(ele);
			break;

		case 2:
			printf("Enter element to insert\n");
			scanf("%d", &ele);
			insertAtBeg(ele);
			break;

		case 3:
			printf("Enter position to enter element\n");
			scanf("%d", &pos);
			printf("Enter element to enter at that posi\n");
			scanf("%d", &ele);
			count = listNodeCount();
			insertAtPos(ele, pos,count);
			break;
		case 4:
			display();
			break;
		case 5:
			count = listNodeCount();
			printf("Count is : %d ", count);
			break;
		case 6:
			deleteFromEnd();
			break;
		case 7:
			deleteFromBeg();
			break;
		case 8:
			printf("Enter position to enter element\n");
			scanf("%d", &pos);
			count = listNodeCount();
			deleteFromPos(pos, count);
			break;
		}
	}
	printf("Thanks Bye\n");
}

void display()
{
	struct node *trav = head;
	if (head == NULL)
	{
		printf("List is empty\n");
		return;
	}
	
	 while (trav != NULL)
	 {
		printf("%d->", trav->data);
		trav = trav->next;

	 }
	
}

void insertAtEnd(int ele)
{

	struct node *temp = (struct node *)malloc(sizeof(struct node));
	struct node *trav = head;

	temp->data = ele;
	temp->next = NULL;
	temp->prev = NULL;

	if(head == NULL)
	{
		head = temp;
		return;
	}
	  
	while (trav->next != NULL)
	{
		trav = trav->next;
	}
	trav->next = temp;
	temp->prev = trav;
	return;
}

void insertAtBeg(int ele)
{
	struct node *trav = head;
	struct node *temp = (struct node *)malloc(sizeof(struct node));
	temp->data = ele;
	temp->next = NULL;
	temp->prev = NULL;

	if (head == NULL)
	{
		head = temp;
		return;
	}
	else
	{
		temp->next = head;
		temp->prev = NULL;
		trav->prev = temp;
		head = temp;
		return;
	}


}

void insertAtPos(int ele, int pos,int count)
{
	struct node *trav = head;
	struct node *temp = (struct node *)malloc(sizeof(struct node));
	temp->data = ele;
	temp->next = NULL;
	temp->prev = NULL;

	int i = 1;
	if (pos == 1)
	{
		insertAtBeg(ele);
		return;
	}
	if(pos == count)
	{
		insertAtEnd(ele);
		return;
	}

	while (i < (pos - 1))
	{
		trav = trav->next;
		i++;
	}
	temp->next = trav->next;
	temp->prev = trav;
	trav->next = temp;
	return;
}

int listNodeCount()
{
	int count = 0;
	struct node *trav = head;

	if (head == NULL)
	{
		printf("List is Empty\n");
		return 0;
	}

	while (trav != NULL)
	{	
		trav = trav->next;
		count++;
	}

	return count;
}

void deleteFromEnd()
{
	struct node *trav = head;
	struct node *target;

	if(head == NULL)
	{
		printf("LIST IS EMPTY\n");
		return;
	}

	if(trav->next == NULL)
	{
		deleteFromBeg();
		return;
	}
	
	while (trav->next->next != NULL)
	{
		trav = trav->next;
	}
	target = trav->next;
	trav->next = NULL;
	free(target);
}

void deleteFromBeg()
{
	struct node *target;
	struct node *trav = head;

	if (head == NULL)
	{
		printf("LIST IS ALREADY EMPTY\n");
		return;
	}
	
	target = trav;
	trav = trav->next;
	head = trav;
	free(target);
}

void deleteFromPos(int pos, int count)
{
	int i = 1;
	struct node *trav = head;
	struct node *target;

	if (pos == 1)
	{
		deleteFromBeg();
		return;
	}
	if (pos == count)
	{
		deleteFromEnd();
		return;
	}

	while (i < (pos - 1))
	{
		i++;
		trav = trav->next;
	}
	target = trav->next;
	target->next->prev = trav;
	trav->next = target->next;
	free(target);
}
